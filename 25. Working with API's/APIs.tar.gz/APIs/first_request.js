var request = require('request');

request('http://www.google.com', function (error, response, body) {
    if(error){
        console.log("Error!");
    }else{
        if(response.statusCode == 200){
            console.log('body:', body); // Print the HTML for the Google homepage.
            console.log("Tudo ok!");
        }else{
            console.log("Resposta com erro!");
        }
    }
});