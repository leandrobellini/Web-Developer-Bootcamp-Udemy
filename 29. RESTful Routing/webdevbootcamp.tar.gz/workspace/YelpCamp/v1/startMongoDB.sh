mongod --bind_ip=$IP --nojournal
